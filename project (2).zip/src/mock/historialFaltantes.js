const historialFaltantes = [
  // Ejemplo de estructura
  // {
  //   id: 1,
  //   fecha: "2023-05-15T14:30:00",
  //   proveedor: "Verdura",
  //   insumo: "Cilantro"
  // }
];

export default historialFaltantes;