const historialFaltantesAgrupado = [
  // Ejemplo de estructura
  // {
  //   id: 1,
  //   fechaReporte: "2023-05-15T14:30:00",
  //   items: [
  //     { proveedor: "Verdura", insumo: "Cilantro" },
  //     { proveedor: "Plásticos y desechables", insumo: "Platos 855" }
  //   ]
  // }
];

export default historialFaltantesAgrupado;