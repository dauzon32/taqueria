const proveedores = {
  "Verdura": [
    { id: 1, nombre: "Papa", unidades: ["kg", "bulto"] },
    { id: 2, nombre: "Cebolla amarilla", unidades: ["kg", "bulto"] },
    { id: 3, nombre: "Cebolla blanca", unidades: ["kg", "bulto"] },
    { id: 4, nombre: "Limón persa", unidades: ["kg"] },
    { id: 5, nombre: "Chile habanero", unidades: ["kg"] },
    { id: 6, nombre: "Chile jalapeño", unidades: ["kg"] },
    { id: 7, nombre: "Cilantro", unidades: ["rollo"] }
  ],
  "Plásticos y desechables": [
    { id: 8, nombre: "Platos 855", unidades: ["bulto"] },
    { id: 9, nombre: "Platos 0.66", unidades: ["bulto"] },
    { id: 10, nombre: "Bolsas 25 × 35 polisera", unidades: ["rollo"] },
    { id: 11, nombre: "Bolsa de camisa polisera chica", unidades: ["kilo"] },
    { id: 12, nombre: "Ketchup Larikota", unidades: ["galón"] },
    { id: 13, nombre: "Bolsas 8 × 22", unidades: ["kg"] },
    { id: 14, nombre: "Aluminio de 50", unidades: ["pza"] },
    { id: 15, nombre: "Cebolla molida", unidades: ["kg", "gramos"] },
    { id: 16, nombre: "Ajo molido", unidades: ["kg", "gramos"] },
    { id: 17, nombre: "Palillos", unidades: ["cajita"] },
    { id: 18, nombre: "Servitoallas", unidades: ["paquete"] },
    { id: 19, nombre: "Cacahuate crudo", unidades: ["kg"] },
    { id: 20, nombre: "Chile de árbol", unidades: ["kg", "gramos"] },
    { id: 21, nombre: "Consomé de pollo", unidades: ["kg"] },
    { id: 22, nombre: "Botes del Pariente tapa roja", unidades: ["pza"] },
    { id: 23, nombre: "Sal", unidades: ["kg"] }
  ],
  "Carne": [
    { id: 24, nombre: "Pulpa blanca", unidades: ["pza"] }
  ],
  "Dipromex": [
    { id: 25, nombre: "Mega", unidades: ["lt"] },
    { id: 26, nombre: "Parri Clean", unidades: ["lt"] },
    { id: 27, nombre: "Jabón supremo", unidades: ["lt"] },
    { id: 28, nombre: "Servilletas", unidades: ["caja"] },
    { id: 29, nombre: "Aroma", unidades: ["lt"] }
  ]
};

export default proveedores;