const gastos = [
  // Ejemplo de estructura
  // {
  //   id: 1,
  //   fecha: "2023-05-15T10:00:00",
  //   proveedor: "Verdura",
  //   insumo: "Papa",
  //   cantidad: 10,
  //   unidad: "kg",
  //   costoUnitario: 15, // Costo por unidad
  //   costoTotal: 150 // Cantidad * Costo Unitario
  // }
];

export default gastos;