import React, { useState, useEffect } from 'react';
import HelpTooltip from './HelpTooltip';

const InsumoRow = ({ proveedor, insumo, onSeleccionar, isVisible, isEven }) => {
  const [cantidad, setCantidad] = useState('');
  const [unidad, setUnidad] = useState(insumo.unidades[0]);
  const [seleccionado, setSeleccionado] = useState(false);
  const [error, setError] = useState('');
  const [stock, setStock] = useState(0);

  // Cargar stock actual del localStorage
  useEffect(() => {
    const savedStock = localStorage.getItem(`stock-${insumo.id}`);
    if (savedStock) {
      setStock(parseInt(savedStock));
    }
  }, [insumo.id]);

  const handleCantidadChange = (e) => {
    const value = e.target.value;
    setCantidad(value);
    if (value === '' || (/^\d+$/.test(value) && parseInt(value) > 0)) {
      setError('');
      // Si la cantidad es válida y mayor a 0, seleccionar automáticamente
      if (parseInt(value) > 0) {
        setSeleccionado(true);
        onSeleccionar(proveedor, insumo.id, value, unidad, true);
      } else {
        // Si la cantidad es 0 o vacía, deseleccionar
        setSeleccionado(false);
        onSeleccionar(proveedor, insumo.id, 0, unidad, false);
      }
    } else {
      setError('Cantidad debe ser número mayor a 0');
      setSeleccionado(false); // Deseleccionar si hay error
      onSeleccionar(proveedor, insumo.id, 0, unidad, false);
    }
  };

  const actualizarStock = (nuevaCantidad) => {
    const nuevoStock = stock - nuevaCantidad;
    setStock(nuevoStock);
    localStorage.setItem(`stock-${insumo.id}`, nuevoStock.toString());
  };

  const handleSeleccionar = (e) => {
    const isChecked = e.target.checked;
    
    if (isChecked && !cantidad) {
      setError('Ingresa cantidad primero');
      e.preventDefault();
      return;
    }

    setSeleccionado(isChecked);
    if (isChecked && cantidad) {
       // Solo actualizar stock si se selecciona y hay cantidad
       actualizarStock(parseInt(cantidad));
       onSeleccionar(proveedor, insumo.id, cantidad, unidad, true);
    } else {
       // Si se deselecciona, no actualizar stock aquí (se maneja en App.js si se elimina del pedido)
       onSeleccionar(proveedor, insumo.id, 0, unidad, false);
    }
  };

  if (!isVisible) return null;

  return (
    <tr className={`border-b border-gray-200 hover:bg-gray-50 ${error ? 'bg-red-50' : ''} ${isEven ? 'bg-gray-50' : 'bg-white'}`}>
      <td className="px-4 py-2 border">{proveedor}</td>
      <td className="px-4 py-2 border">
        <div className="flex items-center">
          {insumo.nombre}
          <HelpTooltip content={`Stock actual: ${stock} ${unidad}`} />
        </div>
      </td>
      <td className="px-4 py-2 border">
        <input
          type="number"
          min="1"
          max={stock}
          className={`w-20 px-2 py-1 border rounded ${error ? 'border-red-500' : ''}`}
          value={cantidad}
          onChange={handleCantidadChange}
        />
        {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
      </td>
      <td className="px-4 py-2 border">
        {insumo.unidades.length > 1 ? (
          <select
            className="px-2 py-1 border rounded"
            value={unidad}
            onChange={(e) => setUnidad(e.target.value)}
          >
            {insumo.unidades.map(u => (
              <option key={u} value={u}>{u}</option>
            ))}
          </select>
        ) : (
          <span>{insumo.unidades[0]}</span>
        )}
      </td>
      <td className="px-4 py-2 border text-center">
        <input
          type="checkbox"
          checked={seleccionado}
          onChange={handleSeleccionar}
          className="h-5 w-5"
          disabled={stock <= 0}
        />
      </td>
      <td className="px-4 py-2 border text-center">
        <span className={`px-2 py-1 rounded-full text-xs ${stock < 5 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
          {stock} en stock
        </span>
      </td>
    </tr>
  );
};

export default InsumoRow;

// DONE