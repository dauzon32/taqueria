import React from 'react';

const HistorialFaltantesAgrupadoTable = ({ historial }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 overflow-x-auto">
      <h2 className="text-xl font-bold mb-4">Historial de Faltantes Reportados (Agrupado)</h2>
      {historial.length === 0 ? (
        <p className="text-gray-500">No hay reportes de faltantes registrados</p>
      ) : (
        <div className="space-y-6">
          {/* Ordenar el historial por fecha de reporte descendente */}
          {historial.sort((a, b) => new Date(b.fechaReporte) - new Date(a.fechaReporte)).map(reporte => (
            <div key={reporte.id} className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-bold text-lg mb-2">Reporte del: {new Date(reporte.fechaReporte).toLocaleString()}</h3>
              {reporte.items && reporte.items.length > 0 ? ( // Verificar si items existe y no está vacío
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="px-4 py-2 border text-left">Proveedor</th>
                      <th className="px-4 py-2 border text-left">Insumo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reporte.items.map((item, index) => (
                      <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                        {/* Asegurarnos de que item.proveedor y item.insumo se están renderizando */}
                        <td className="px-4 py-2 border">{item.proveedor}</td>
                        <td className="px-4 py-2 border">{item.insumo}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <p className="text-gray-500">Este reporte no contiene insumos faltantes.</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistorialFaltantesAgrupadoTable;

// DONE