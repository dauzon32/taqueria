import React, { useState } from 'react';

const ProveedorCard = ({ nombre, insumos, onAgregarPedido }) => {
  const [cantidades, setCantidades] = useState({});
  const [unidades, setUnidades] = useState({});

  const handleCantidadChange = (id, value) => {
    setCantidades(prev => ({ ...prev, [id]: value }));
    if (value > 0 && unidades[id]) {
      onAgregarPedido(nombre, id, value, unidades[id]);
    }
  };

  const handleUnidadChange = (id, value) => {
    setUnidades(prev => ({ ...prev, [id]: value }));
    if (cantidades[id] > 0) {
      onAgregarPedido(nombre, id, cantidades[id], value);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-bold text-green-800 mb-4">{nombre}</h2>
      <div className="space-y-4">
        {insumos.map(insumo => (
          <div key={insumo.id} className="flex items-center justify-between">
            <span className="font-medium">{insumo.nombre}</span>
            <div className="flex space-x-2">
              <input
                type="number"
                min="0"
                className="w-20 px-2 py-1 border rounded"
                onChange={(e) => handleCantidadChange(insumo.id, e.target.value)}
              />
              <select 
                className="px-2 py-1 border rounded"
                onChange={(e) => handleUnidadChange(insumo.id, e.target.value)}
                defaultValue={insumo.unidades[0]}
              >
                {insumo.unidades.map(unidad => (
                  <option key={unidad} value={unidad}>{unidad}</option>
                ))}
              </select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProveedorCard;