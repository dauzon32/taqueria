const TaqueriaIdeas = () => {
  const ideas = [
    {
      titulo: "App de Pedidos",
      descripcion: "Desarrolla una app móvil para que clientes pidan directamente",
      beneficio: "Reduce errores y aumenta ventas en 30%"
    },
    {
      titulo: "Programa de Fidelidad",
      descripcion: "Sistema de puntos por compras (10 tacos = 1 gratis)",
      beneficio: "Aumenta clientes recurrentes"
    },
    {
      titulo: "WhatsApp Business",
      descripcion: "Usa la versión empresarial con catálogo y respuestas automáticas",
      beneficio: "Mejora la comunicación con clientes"
    },
    {
      titulo: "Análisis de Inventario",
      descripcion: "Registra qué tacos se venden más y a qué hora",
      beneficio: "Optimiza compras y reduce merma"
    },
    {
      titulo: "Promociones por Horario",
      descripcion: "Tacos felices de 3-5pm con 20% de descuento",
      beneficio: "Aprovecha horas bajas"
    }
  ];

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-orange-600 mb-4">Ideas para tu Taquería</h2>
      <div className="space-y-4">
        {ideas.map((idea, index) => (
          <div key={index} className="border-l-4 border-orange-500 pl-4">
            <h3 className="font-bold text-lg">{idea.titulo}</h3>
            <p className="text-gray-700">{idea.descripcion}</p>
            <p className="text-sm text-orange-600 font-medium">{idea.beneficio}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TaqueriaIdeas;