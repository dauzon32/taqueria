import React from 'react';

const HistorialFaltantesTable = ({ historial }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 overflow-x-auto">
      <h2 className="text-xl font-bold mb-4">Historial de Faltantes Reportados</h2>
      {historial.length === 0 ? (
        <p className="text-gray-500">No hay reportes de faltantes registrados</p>
      ) : (
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 border">Fecha</th>
              <th className="px-4 py-2 border">Proveedor</th>
              <th className="px-4 py-2 border">Insumo</th>
            </tr>
          </thead>
          <tbody>
            {historial.map(item => (
              <tr key={item.id} className="border-b border-gray-200 hover:bg-gray-50">
                <td className="px-4 py-2 border">{new Date(item.fecha).toLocaleString()}</td>
                <td className="px-4 py-2 border">{item.proveedor}</td>
                <td className="px-4 py-2 border">{item.insumo}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default HistorialFaltantesTable;