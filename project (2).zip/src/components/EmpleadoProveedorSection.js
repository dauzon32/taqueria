import React from 'react';
import EmpleadoInsumoRow from './EmpleadoInsumoRow';

const EmpleadoProveedorSection = ({ nombre, insumos, onMarcarFalta, searchTerm }) => {
  const filteredInsumos = insumos.filter(insumo =>
    insumo.nombre.toLowerCase().includes(searchTerm)
  );

  if (filteredInsumos.length === 0) return null;

  return (
    <>
      <tr className="border-b-2 border-gray-300 bg-gray-800 text-white">
        <td colSpan="3" className="px-4 py-3">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">{nombre}</h2>
            <span className="bg-white text-gray-800 px-2 py-1 rounded text-sm">
              {filteredInsumos.length} insumos
            </span>
          </div>
        </td>
      </tr>
      {filteredInsumos.map((insumo, index) => (
        <EmpleadoInsumoRow
          key={insumo.id}
          proveedor={nombre}
          insumo={insumo}
          onMarcarFalta={onMarcarFalta}
          isVisible={true}
          isEven={index % 2 === 0}
        />
      ))}
      <tr className="h-4"><td colSpan="3"></td></tr>
    </>
  );
};

export default EmpleadoProveedorSection;