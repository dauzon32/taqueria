import React, { useState } from 'react';

const FinanzasTable = ({ gastos }) => {
  const [filtroTiempo, setFiltroTiempo] = useState('dia'); // 'dia', 'semana', 'mes', 'total'

  const filtrarGastos = (gastos, filtro) => {
    const now = new Date();
    return gastos.filter(gasto => {
      const fechaGasto = new Date(gasto.fecha);
      switch (filtro) {
        case 'dia':
          return fechaGasto.toDateString() === now.toDateString();
        case 'semana':
          const startOfWeek = new Date(now);
          startOfWeek.setDate(now.getDate() - now.getDay());
          const endOfWeek = new Date(startOfWeek);
          endOfWeek.setDate(startOfWeek.getDate() + 6);
          return fechaGasto >= startOfWeek && fechaGasto <= endOfWeek;
        case 'mes':
          return fechaGasto.getMonth() === now.getMonth() && fechaGasto.getFullYear() === now.getFullYear();
        case 'total':
        default:
          return true;
      }
    });
  };

  const gastosFiltrados = filtrarGastos(gastos, filtroTiempo);

  const totalGastos = gastosFiltrados.reduce((sum, gasto) => sum + gasto.costoTotal, 0);

  return (
    <div className="bg-white rounded-lg shadow-md p-6 overflow-x-auto">
      <h2 className="text-xl font-bold mb-4">Control de Finanzas - Gastos</h2>
      
      <div className="mb-4 flex space-x-4">
        <button
          onClick={() => setFiltroTiempo('dia')}
          className={`px-4 py-2 rounded ${filtroTiempo === 'dia' ? 'bg-red-700 text-white' : 'bg-gray-200'}`}
        >
          Hoy
        </button>
        <button
          onClick={() => setFiltroTiempo('semana')}
          className={`px-4 py-2 rounded ${filtroTiempo === 'semana' ? 'bg-red-700 text-white' : 'bg-gray-200'}`}
        >
          Semana
        </button>
        <button
          onClick={() => setFiltroTiempo('mes')}
          className={`px-4 py-2 rounded ${filtroTiempo === 'mes' ? 'bg-red-700 text-white' : 'bg-gray-200'}`}
        >
          Mes
        </button>
        <button
          onClick={() => setFiltroTiempo('total')}
          className={`px-4 py-2 rounded ${filtroTiempo === 'total' ? 'bg-red-700 text-white' : 'bg-gray-200'}`}
        >
          Total
        </button>
      </div>

      <div className="mb-4 text-lg font-semibold">
        Total Gastado ({filtroTiempo}): ${totalGastos.toFixed(2)}
      </div>

      {gastosFiltrados.length === 0 ? (
        <p className="text-gray-500">No hay gastos registrados para este período</p>
      ) : (
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 border">Fecha</th>
              <th className="px-4 py-2 border">Proveedor</th>
              <th className="px-4 py-2 border">Insumo</th>
              <th className="px-4 py-2 border">Cantidad</th>
              <th className="px-4 py-2 border">Unidad</th>
              <th className="px-4 py-2 border">Costo Unitario</th>
              <th className="px-4 py-2 border">Costo Total</th>
            </tr>
          </thead>
          <tbody>
            {gastosFiltrados.map(gasto => (
              <tr key={gasto.id} className="border-b border-gray-200 hover:bg-gray-50">
                <td className="px-4 py-2 border">{new Date(gasto.fecha).toLocaleString()}</td>
                <td className="px-4 py-2 border">{gasto.proveedor}</td>
                <td className="px-4 py-2 border">{gasto.insumo}</td>
                <td className="px-4 py-2 border">{gasto.cantidad}</td>
                <td className="px-4 py-2 border">{gasto.unidad}</td>
                <td className="px-4 py-2 border">${gasto.costoUnitario.toFixed(2)}</td>
                <td className="px-4 py-2 border">${gasto.costoTotal.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default FinanzasTable;