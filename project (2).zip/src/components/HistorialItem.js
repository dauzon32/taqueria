import React from 'react';

const HistorialItem = ({ item }) => {
  return (
    <tr className="border-b border-gray-200 hover:bg-gray-50">
      <td className="px-4 py-2 border">{new Date(item.fecha).toLocaleString()}</td>
      <td className="px-4 py-2 border">{item.proveedor}</td>
      <td className="px-4 py-2 border">{item.insumo}</td>
      <td className="px-4 py-2 border">{item.cantidad}</td>
      <td className="px-4 py-2 border">{item.unidad}</td>
    </tr>
  );
};

export default HistorialItem;