import React from 'react';

const EmpleadoListaFaltantes = ({ faltantes, onRegistrarFaltantes, onLimpiarFaltantes }) => { // Recibir la nueva prop
  const generarListaFaltantes = () => {
    let texto = '📋 *INSUMOS FALTANTES REPORTADOS* 📋\n\n';
    texto += `📅 Fecha: ${new Date().toLocaleDateString()}\n\n`;
    
    Object.entries(faltantes).forEach(([proveedor, items]) => {
      if (items && items.length > 0) {
        texto += `🔹 *${proveedor.toUpperCase()}*\n`;
        items.forEach(item => {
          texto += `- ${item.insumo}\n`;
        });
        texto += "\n";
      }
    });

    if (Object.keys(faltantes).length === 0 || Object.values(faltantes).every(items => !items || items.length === 0)) {
        texto += "¡No hay insumos marcados como faltantes en este momento!";
    } else {
        texto += '¡Favor de revisar y surtir!';
    }

    return texto;
  };

  const handleRegistrarFaltantes = () => {
    const hayFaltantes = Object.values(faltantes).some(items => items && items.length > 0);

    if (!hayFaltantes) {
        alert("No hay insumos marcados como faltantes para registrar.");
        return;
    }
    
    const itemsParaHistorial = [];
    Object.entries(faltantes).forEach(([proveedor, items]) => {
        if (Array.isArray(items) && items.length > 0) {
            items.forEach(item => {
                 if (item.proveedor && item.insumo) {
                    itemsParaHistorial.push({
                        proveedor: item.proveedor,
                        insumo: item.insumo
                    });
                }
            });
        }
    });

    if (itemsParaHistorial.length > 0) {
        const nuevoReporte = {
            id: Date.now() + Math.random(),
            fechaReporte: new Date().toISOString(),
            items: itemsParaHistorial
        };
        onRegistrarFaltantes(nuevoReporte);
        alert("Reporte de faltantes registrado en el historial.");
    } else {
         alert("No hay insumos marcados como faltantes para registrar.");
    }
  };

  const handleLimpiar = () => {
      onLimpiarFaltantes(); // Llama a la función de limpieza pasada desde App.js
      alert("Lista de faltantes limpiada.");
  };


  return (
    <div className="bg-gray-100 p-6 rounded-lg sticky top-4">
      <div className="flex justify-between items-center mb-4"> {/* Contenedor para título y botón */}
        <h2 className="text-xl font-bold">Lista de Faltantes</h2>
         {/* Botón de Limpiar */}
        <button
          onClick={handleLimpiar}
          className="text-sm text-red-600 hover:text-red-800"
        >
          Limpiar
        </button>
      </div>
      
      {Object.keys(faltantes).length === 0 || Object.values(faltantes).every(items => !items || items.length === 0) ? (
        <p className="text-gray-500">No hay insumos marcados como faltantes</p>
      ) : (
        <>
          {Object.entries(faltantes).map(([proveedor, items]) => (
            items && items.length > 0 && (
              <div key={proveedor} className="mb-6 bg-white p-4 rounded shadow">
                <h3 className="font-bold text-lg mb-2">{proveedor}</h3>
                <ul className="list-disc pl-5 mb-3">
                  {items.map((item, index) => (
                    <li key={index}>
                      {item.insumo}
                    </li>
                  ))}
                </ul>
              </div>
            )
          ))}
          
          <div className="mt-6">
            <button
              onClick={handleRegistrarFaltantes}
              className="w-full bg-red-700 text-white px-4 py-2 rounded hover:bg-red-800 transition"
            >
              Registrar Faltantes
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default EmpleadoListaFaltantes;