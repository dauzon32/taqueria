import React, { useState } from 'react';

const HistorialTable = ({ historial, onRegistrarGasto }) => {
  const [costos, setCostos] = useState({}); // Estado local para costos unitarios

  const handleCostoChange = (id, value) => {
    setCostos(prev => ({ ...prev, [id]: value }));
  };

  const handleRegistrarGastoClick = (item) => {
    const costoUnitario = parseFloat(costos[item.id]);
    if (!isNaN(costoUnitario) && costoUnitario > 0) {
      const gastoItem = {
        id: Date.now() + Math.random(),
        fecha: new Date().toISOString(),
        proveedor: item.proveedor,
        insumo: item.insumo,
        cantidad: item.cantidad,
        unidad: item.unidad,
        costoUnitario: costoUnitario,
        costoTotal: item.cantidad * costoUnitario
      };
      onRegistrarGasto(gastoItem);
      alert(`Gasto de ${item.insumo} registrado en Finanzas.`);
      // Opcional: Limpiar el campo de costo después de registrar
      // setCostos(prev => { delete prev[item.id]; return { ...prev }; });
    } else {
      alert("Ingresa un costo unitario válido mayor a 0.");
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 overflow-x-auto">
      <h2 className="text-xl font-bold mb-4">Historial de Pedidos (Jefe)</h2>
      {historial.length === 0 ? (
        <p className="text-gray-500">No hay pedidos registrados</p>
      ) : (
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 border">Fecha</th>
              <th className="px-4 py-2 border">Proveedor</th>
              <th className="px-4 py-2 border">Insumo</th>
              <th className="px-4 py-2 border">Cantidad</th>
              <th className="px-4 py-2 border">Unidad</th>
              <th className="px-4 py-2 border">Costo Unitario</th>
              <th className="px-4 py-2 border">Registrar Gasto</th>
            </tr>
          </thead>
          <tbody>
            {historial.map(item => (
              <tr key={item.id} className="border-b border-gray-200 hover:bg-gray-50">
                <td className="px-4 py-2 border">{new Date(item.fecha).toLocaleString()}</td>
                <td className="px-4 py-2 border">{item.proveedor}</td>
                <td className="px-4 py-2 border">{item.insumo}</td>
                <td className="px-4 py-2 border">{item.cantidad}</td>
                <td className="px-4 py-2 border">{item.unidad}</td>
                <td className="px-4 py-2 border">
                   <input
                      type="number"
                      min="0"
                      step="0.01"
                      className="w-20 px-2 py-1 border rounded"
                      value={costos[item.id] || ''}
                      onChange={(e) => handleCostoChange(item.id, e.target.value)}
                    />
                </td>
                <td className="px-4 py-2 border text-center">
                   <button
                      onClick={() => handleRegistrarGastoClick(item)}
                      className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition text-sm"
                    >
                      Registrar
                    </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default HistorialTable;