import React, { useState } from 'react';

const ListaPedidos = ({ pedidos, onRegistrarPedido, onLimpiarSeleccion }) => {
  const [notas, setNotas] = useState('');

  const generarListaProveedor = (proveedor, items) => {
    return items.map(item => 
      `${item.cantidad} ${item.unidad} de ${item.nombre}`
    ).join('\n');
  };

  const generarPedidoCompleto = () => {
    let texto = '📋 *PEDIDO DE INSUMOS* 📋\n\n';
    texto += `📅 Fecha: ${new Date().toLocaleDateString()}\n\n`;
    
    Object.entries(pedidos).forEach(([proveedor, items]) => {
      if (items.length > 0) {
        texto += `🔹 *${proveedor.toUpperCase()}*\n`;
        texto += `${generarListaProveedor(proveedor, items)}\n\n`;
      }
    });

    if (notas) {
      texto += `📝 *NOTAS:*\n${notas}\n\n`;
    }

    texto += '¡Gracias por su pronto surtido!';
    return texto;
  };

  const copiarPedidoCompleto = () => {
    const texto = generarPedidoCompleto();
    navigator.clipboard.writeText(texto);
    alert("Pedido completo copiado al portapeles. Puede pegarlo en WhatsApp.");
  };

  const copiarListaProveedor = (proveedor) => {
    const texto = `*Pedido para ${proveedor}:*\n${generarListaProveedor(proveedor, pedidos[proveedor])}`;
    navigator.clipboard.writeText(texto);
    alert(`Lista de ${proveedor} copiada!\nPega esto directamente en WhatsApp Business`);
  };

  const handlePedir = () => {
    if (Object.keys(pedidos).length === 0) {
      alert("No hay items en el pedido para registrar.");
      return;
    }
    // Llama a la función de registro pasada desde App.js
    onRegistrarPedido(pedidos);
    // Limpiar la selección después de registrar
    onLimpiarSeleccion();
    setNotas('');
    alert("Pedido registrado en el historial.");
  };


  const limpiarTodo = () => {
    onLimpiarSeleccion();
    setNotas('');
  };

  return (
    <div className="bg-gray-100 p-6 rounded-lg sticky top-4">
      <h2 className="text-xl font-bold mb-4">Resumen de Pedido</h2>
      
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">Notas adicionales:</label>
        <textarea
          value={notas}
          onChange={(e) => setNotas(e.target.value)}
          className="w-full px-3 py-2 border rounded-md"
          rows="3"
          placeholder="Ej: 'Necesitamos los limones más jugosos'"
        />
      </div>

      {Object.keys(pedidos).length === 0 ? (
        <p className="text-gray-500">No hay items en el pedido</p>
      ) : (
        <>
          <div className="mb-6">
            <button
              onClick={copiarPedidoCompleto}
              className="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition mb-2"
            >
              Copiar Pedido Completo
            </button>
             <button
              onClick={handlePedir}
              className="w-full bg-red-700 text-white px-4 py-2 rounded hover:bg-red-800 transition"
            >
              Registrar Pedido
            </button>
          </div>

          {Object.entries(pedidos).map(([proveedor, items]) => (
            items.length > 0 && (
              <div key={proveedor} className="mb-6 bg-white p-4 rounded shadow">
                <h3 className="font-bold text-lg mb-2">{proveedor}</h3>
                <ul className="list-disc pl-5 mb-3">
                  {items.map((item, index) => (
                    <li key={index}>
                      {item.cantidad} {item.unidad} de {item.nombre}
                    </li>
                  ))}
                </ul>
                <div className="flex space-x-2">
                  <button
                    onClick={() => copiarListaProveedor(proveedor)}
                    className="flex-1 bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600 transition text-sm"
                  >
                    Copiar Lista ({items.length})
                  </button>
                </div>
              </div>
            )
          ))}
          
          <div className="mt-6">
            <button
              onClick={limpiarTodo}
              className="w-full bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition"
            >
              Limpiar Todo
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default ListaPedidos;