import React, { useState } from 'react';
import HelpTooltip from './HelpTooltip';

const EmpleadoInsumoRow = ({ proveedor, insumo, onMarcarFalta, isVisible, isEven }) => {
  const [falta, setFalta] = useState(false);

  const handleMarcarFalta = (e) => {
    const isChecked = e.target.checked;
    setFalta(isChecked);
    onMarcarFalta(proveedor, insumo.id, isChecked);
  };

  if (!isVisible) return null;

  return (
    <tr className={`border-b border-gray-200 hover:bg-gray-50 ${isEven ? 'bg-gray-50' : 'bg-white'}`}>
      <td className="px-4 py-2 border">{proveedor}</td>
      <td className="px-4 py-2 border">
        <div className="flex items-center">
          {insumo.nombre}
          <HelpTooltip content={`Unidades disponibles: ${insumo.unidades.join(', ')}`} />
        </div>
      </td>
      <td className="px-4 py-2 border text-center">
        <input
          type="checkbox"
          checked={falta}
          onChange={handleMarcarFalta}
          className="h-5 w-5"
        />
      </td>
    </tr>
  );
};

export default EmpleadoInsumoRow;