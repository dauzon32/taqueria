import React, { useState } from 'react';

const PasswordInput = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const correctPassword = 'pdmu2020'; // Contraseña fija

  const handleLogin = () => {
    if (password === correctPassword) {
      onLogin(true);
      setError('');
    } else {
      setError('Contraseña incorrecta');
      onLogin(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleLogin();
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-xl text-center">
        <h2 className="text-2xl font-bold mb-4">Acceso Restringido</h2>
        <input
          type="password"
          className={`px-4 py-2 border rounded-lg mb-4 ${error ? 'border-red-500' : 'border-gray-300'}`}
          placeholder="Ingresa la contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyPress={handleKeyPress}
        />
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
        <button
          onClick={handleLogin}
          className="bg-red-700 text-white px-6 py-2 rounded-lg font-semibold hover:bg-red-800 transition"
        >
          Entrar
        </button>
      </div>
    </div>
  );
};

export default PasswordInput;