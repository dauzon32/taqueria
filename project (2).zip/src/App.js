import React, { useState, useEffect } from 'react';
import proveedores from './mock/proveedores';
import historialData from './mock/historial'; // Historial de pedidos del jefe
import historialFaltantesData from './mock/historialFaltantes'; // Historial de faltantes (anterior, ya no se usa directamente para mostrar)
import historialFaltantesAgrupadoData from './mock/historialFaltantesAgrupado'; // Nuevo mock de historial agrupado
import gastosData from './mock/gastos'; // Nuevo mock de gastos
import ListaPedidos from './components/ListaPedidos';
import InsumoRow from './components/InsumoRow';
import EmpleadoProveedorSection from './components/EmpleadoProveedorSection';
import EmpleadoListaFaltantes from './components/EmpleadoListaFaltantes';
import EmpleadoInsumoRow from './components/EmpleadoInsumoRow';
import HistorialTable from './components/HistorialTable'; // Historial de pedidos del jefe
import HistorialFaltantesTable from './components/HistorialFaltantesTable'; // Historial de faltantes (anterior, ya no se usa directamente para mostrar)
import HistorialFaltantesAgrupadoTable from './components/HistorialFaltantesAgrupadoTable'; // Nuevo componente de historial agrupado
import PasswordInput from './components/PasswordInput'; // Componente de contraseña
import FinanzasTable from './components/FinanzasTable'; // Componente de finanzas

const logoBistecHouseUrl = 'https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0NIgRQ8d8ASzOYnuUx9evHl1k3cs0iWKGPRJ7';

const App = () => {
  const [pedidos, setPedidos] = useState(() => {
    const saved = JSON.parse(localStorage.getItem('pedidos')) || {};
    return saved;
  });

  const [faltantes, setFaltantes] = useState(() => {
    const saved = JSON.parse(localStorage.getItem('faltantes')) || {};
    return saved;
  });

  const [historialPedidos, setHistorialPedidos] = useState(() => {
    const saved = JSON.parse(localStorage.getItem('historialPedidos')) || historialData;
    return saved;
  });

  // Cambiamos el estado para usar el historial agrupado
  const [historialFaltantesAgrupado, setHistorialFaltantesAgrupado] = useState(() => {
    const saved = JSON.parse(localStorage.getItem('historialFaltantesAgrupado')) || historialFaltantesAgrupadoData;
    return saved;
  });

  const [gastos, setGastos] = useState(() => {
    const saved = JSON.parse(localStorage.getItem('gastos')) || gastosData;
    return saved;
  });


  const [vista, setVista] = useState('empleado'); // Vista inicial por defecto para empleados
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Estado para controlar el login del jefe

  useEffect(() => {
    localStorage.setItem('pedidos', JSON.stringify(pedidos));
  }, [pedidos]);

  useEffect(() => {
    localStorage.setItem('faltantes', JSON.stringify(faltantes));
  }, [faltantes]);

  useEffect(() => {
    localStorage.setItem('historialPedidos', JSON.stringify(historialPedidos));
  }, [historialPedidos]);

  // Guardar el nuevo historial agrupado
  useEffect(() => {
    localStorage.setItem('historialFaltantesAgrupado', JSON.stringify(historialFaltantesAgrupado));
  }, [historialFaltantesAgrupado]);

   useEffect(() => {
    localStorage.setItem('gastos', JSON.stringify(gastos));
  }, [gastos]);


  const handleSeleccionarJefe = (proveedor, insumoId, cantidad, unidad, isSelected) => {
    setPedidos(prev => {
      const nuevoPedido = { ...prev };
      if (!nuevoPedido[proveedor]) {
        nuevoPedido[proveedor] = [];
      }

      const insumo = proveedores[proveedor].find(i => i.id === insumoId);
      const itemIndex = nuevoPedido[proveedor].findIndex(
        item => item.nombre === insumo.nombre
      );

      if (!isSelected || cantidad <= 0) {
        if (itemIndex >= 0) {
          nuevoPedido[proveedor].splice(itemIndex, 1);
        }
      } else {
        const item = {
          nombre: insumo.nombre,
          cantidad: Number(cantidad),
          unidad
        };

        if (itemIndex >= 0) {
          nuevoPedido[proveedor][itemIndex] = item;
        } else {
          nuevoPedido[proveedor].push(item);
        }
      }

      if (nuevoPedido[proveedor] && nuevoPedido[proveedor].length === 0) {
        delete nuevoPedido[proveedor];
      }

      return nuevoPedido;
    });
  };

  const handleMarcarFaltaEmpleado = (proveedor, insumoId, isChecked) => {
    setFaltantes(prev => {
      const nuevosFaltantes = { ...prev };
      if (!nuevosFaltantes[proveedor]) {
        nuevosFaltantes[proveedor] = [];
      }

      const insumo = proveedores[proveedor].find(i => i.id === insumoId);
      const itemIndex = nuevosFaltantes[proveedor].findIndex(
        item => item.insumo === insumo.nombre
      );

      if (isChecked) {
        if (itemIndex === -1) {
          nuevosFaltantes[proveedor].push({ proveedor: proveedor, insumo: insumo.nombre });
        }
      } else {
        if (itemIndex >= 0) {
          nuevosFaltantes[proveedor].splice(itemIndex, 1);
        }
      }

      if (nuevosFaltantes[proveedor] && nuevosFaltantes[proveedor].length === 0) {
        delete nuevosFaltantes[proveedor];
      }

      return nuevosFaltantes;
    });
  };

  const handleRegistrarPedidoJefe = (pedidoActual) => {
      const itemsParaHistorial = [];
      Object.entries(pedidoActual).forEach(([proveedor, items]) => {
          if (Array.isArray(items)) {
              items.forEach(item => {
                  itemsParaHistorial.push({
                      id: Date.now() + Math.random(),
                      fecha: new Date().toISOString(),
                      proveedor: proveedor,
                      insumo: item.nombre,
                      cantidad: item.cantidad,
                      unidad: item.unidad
                  });
              });
          }
      });
      setHistorialPedidos(prev => [...itemsParaHistorial, ...prev]);
  };

  const handleRegistrarFaltantesEmpleado = (faltantesActuales) => {
    const hayFaltantes = Object.values(faltantesActuales).some(items => items && items.length > 0);

    if (!hayFaltantes) {
        alert("No hay insumos marcados como faltantes para registrar.");
        return;
    }

    const itemsParaReporte = [];
    Object.entries(faltantesActuales).forEach(([proveedor, items]) => {
        if (Array.isArray(items) && items.length > 0) {
            items.forEach(item => {
                 if (item.proveedor && item.insumo) {
                    itemsParaReporte.push({
                        proveedor: item.proveedor,
                        insumo: item.insumo
                    });
                }
            });
        }
    });

    if (itemsParaReporte.length > 0) {
        const nuevoReporte = {
            id: Date.now() + Math.random(),
            fechaReporte: new Date().toISOString(),
            items: itemsParaReporte
        };
        setHistorialFaltantesAgrupado(prev => [nuevoReporte, ...prev]);
        setFaltantes({}); // Limpiar la lista de faltantes actual
        alert("Reporte de faltantes registrado en el historial.");
    } else {
         alert("No hay insumos marcados como faltantes para registrar.");
    }
  };


  const handleRegistrarGasto = (gastoItem) => {
      setGastos(prev => [gastoItem, ...prev]);
  };


  const handleLimpiarSeleccionJefe = () => {
    setPedidos({});
  };

  const handleLimpiarFaltantesEmpleado = () => {
      setFaltantes({});
  };


  const handleSearch = (term) => {
    setSearchTerm(term);
  };

  // Renderizado condicional basado en la vista y el estado de login
  let content;
  // Si no está logueado Y la vista actual requiere login, mostrar el input de contraseña
  if (!isLoggedIn && (vista === 'jefe' || vista === 'historialJefe' || vista === 'finanzas')) {
      content = <PasswordInput onLogin={setIsLoggedIn} />;
  } else {
      // Si está logueado O la vista actual es la de empleado (pública), mostrar el contenido principal
      content = (
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <img src={logoBistecHouseUrl} alt="Logo Bistec House" className="h-16" />
            <div className="flex space-x-4">
              <button
                onClick={() => setVista('jefe')}
                className={`px-6 py-2 rounded-full font-semibold transition-colors ${vista === 'jefe' ? 'bg-red-700 text-white shadow-lg' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
              >
                Vista Jefe
              </button>
              <button
                onClick={() => setVista('empleado')}
                className={`px-6 py-2 rounded-full font-semibold transition-colors ${vista === 'empleado' ? 'bg-red-700 text-white shadow-lg' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
              >
                Vista Empleado
              </button>
               <button
                onClick={() => setVista('historialJefe')}
                className={`px-6 py-2 rounded-full font-semibold transition-colors ${vista === 'historialJefe' ? 'bg-red-700 text-white shadow-lg' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
              >
                Historial Pedidos
              </button>
               <button
                onClick={() => setVista('historialEmpleado')}
                className={`px-6 py-2 rounded-full font-semibold transition-colors ${vista === 'historialEmpleado' ? 'bg-red-700 text-white shadow-lg' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
              >
                Historial Faltantes
              </button>
               <button
                onClick={() => setVista('finanzas')}
                className={`px-6 py-2 rounded-full font-semibold transition-colors ${vista === 'finanzas' ? 'bg-red-700 text-white shadow-lg' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
              >
                Finanzas
              </button>
               {isLoggedIn && (
                  <button
                      onClick={() => {
                          setIsLoggedIn(false);
                          setVista('empleado');
                      }}
                      className="px-6 py-2 rounded-full font-semibold transition-colors bg-gray-500 text-white hover:bg-gray-600"
                  >
                      Cerrar Sesión
                  </button>
              )}
            </div>
          </div>
          
          {vista === 'jefe' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <div className="mb-6">
                  <input
                    type="text"
                    placeholder="Buscar insumo o proveedor..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value.toLowerCase())}
                  />
                </div>
                
                <div className="bg-white rounded-lg shadow-xl overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-800 text-white">
                        <th className="px-4 py-3 text-left">Proveedor</th>
                        <th className="px-4 py-3 text-left">Insumo</th>
                        <th className="px-4 py-3 text-left">Cantidad</th>
                        <th className="px-4 py-3 text-left">Unidad</th>
                        <th className="px-4 py-3 text-center">Seleccionar</th>
                        <th className="px-4 py-3 text-center">Stock</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(proveedores).map(([nombre, insumos]) => (
                        insumos.filter(insumo => 
                          insumo.nombre.toLowerCase().includes(searchTerm) || 
                          nombre.toLowerCase().includes(searchTerm)
                        ).map((insumo, index) => (
                          <InsumoRow
                            key={insumo.id}
                            proveedor={nombre}
                            insumo={insumo}
                            onSeleccionar={handleSeleccionarJefe}
                            isVisible={true}
                            isEven={index % 2 === 0}
                          />
                        ))
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              
              <div>
                <ListaPedidos 
                  pedidos={pedidos} 
                  onLimpiarSeleccion={handleLimpiarSeleccionJefe}
                  onRegistrarPedido={handleRegistrarPedidoJefe}
                />
              </div>
            </div>
          )}

          {vista === 'empleado' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <div className="mb-6">
                  <input
                    type="text"
                    placeholder="Buscar insumo o proveedor..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value.toLowerCase())}
                  />
                </div>
                <div className="bg-white rounded-lg shadow-xl overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-800 text-white">
                        <th className="px-4 py-3 text-left">Proveedor</th>
                        <th className="px-4 py-3 text-left">Insumo</th>
                        <th className="px-4 py-3 text-center">Falta</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(proveedores).map(([nombre, insumos]) => (
                        insumos.filter(insumo => 
                          insumo.nombre.toLowerCase().includes(searchTerm) || 
                          nombre.toLowerCase().includes(searchTerm)
                        ).map((insumo, index) => (
                          <EmpleadoInsumoRow
                            key={insumo.id}
                            proveedor={nombre}
                            insumo={insumo}
                            onMarcarFalta={handleMarcarFaltaEmpleado}
                            isVisible={true}
                            isEven={index % 2 === 0}
                          />
                        ))
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div>
                <EmpleadoListaFaltantes 
                  faltantes={faltantes} 
                  onRegistrarFaltantes={handleRegistrarFaltantesEmpleado}
                  onLimpiarFaltantes={handleLimpiarFaltantesEmpleado}
                />
              </div>
            </div>
          )}

          {vista === 'historialJefe' && (
            <HistorialTable 
              historial={historialPedidos} 
              onRegistrarGasto={handleRegistrarGasto}
            />
          )}

          {vista === 'historialEmpleado' && (
            <HistorialFaltantesAgrupadoTable historial={historialFaltantesAgrupado} />
          )}

           {vista === 'finanzas' && (
            <FinanzasTable gastos={gastos} />
          )}

        </div>
      );
  }


  return (
    <div className="min-h-screen bg-gray-100 p-6">
      {content}
    </div>
  );
};

export default App;

// DONE